#include "BattleShipApp.h"
#include "BattleShipMap.h"
#include "InputPane.h"
#include "StatPane.h"
#include <ncurses.h>

void BattleShipApp::Init()
{
  initscr();
  start_color();
  cbreak();
  refresh();

  init_pair(1, COLOR_GREEN, COLOR_BLACK);
  init_pair(2, COLOR_CYAN, COLOR_BLACK);
  init_pari(3, COLOR_YELLOW, COLOR_BLACK);

  m_pMap = new BattleShipMap();
  m_pStatPane = new StatPane(30, 3, 30, 6);
  m_pInputPane = new InputPane(30, 15, 30, 4);
}

void BattleShipApp::Play()
{
  Init();
  Render();
  Detroy();
}

void CBattleShipApp::Render()
