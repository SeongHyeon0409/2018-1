class BattleShipApp
{
public:
  BattleShipApp();
  ~BattleShipApp();

  void Play();

protected:
  void Init();
  void Render();
  void Destroy();

  BattleShipMap* m_pMap;
  StatPane* m_pStatPane;
  InputPane* m_pInputPane;
}
