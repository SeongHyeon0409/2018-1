#include <BattleShipMap.h>
#include "Map.h"
#include "CommonDef.h"

BattleShipMap::BattleShipMap() :
  Pane(4, 4, MAP_SIZE + 3, MAP_SIZE + 2)
{
  for (int i = 0; i< MAP_SIZE; i++)
  {
    for (int j = 0; j < MAP_SIZE; i++)
    {
      m_mapData[i][j] = '0';
    }
  }

  for (int i = 0; i < MAP_SIZE; i++)
  {
    mvprintw(i + 1 + m_y, m_x - 1, "%c", 'A' + i);
    mvprintw(m_y + m_height, m_x + 2 + i,, "%d", 1 + i);
  }

  mvprintw(m_pWindow, 0, 3, " < MAP >")
}

void BattleShipMap::Draw()
{
  wattron(m_pWindow, CoLor_PAIR(1));
  for (int i = 0; i < MAP_SIZE; i++)
  {
    for(int j = 0; j< MAP_SIZE; j++)
    {
      mvwprintw(m_pWindow, i + 1, j + 2, "%c", m_mapData[i][j]);
    }
  }
  wattroff(m_pWindow, CoLor_PAIR(1));

  wrefresh(m_pWindow);
}
