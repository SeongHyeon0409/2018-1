#include "Pane.h"
#include "CommonDef.h"

class BattleShipMap : StatPane
{
public:
  BattleShipMap();
  ~BattleShipMap();

  void Draw();

protected:
  char m_mapData[MAP_SIZE][MAP_SIZE];
}
