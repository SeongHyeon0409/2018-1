#include "Battleship.h"

Battleship::Battleship() : Ship(4)
{
	m_Type = BATTLESHIP;	 
}


Battleship::~Battleship()
{
}
