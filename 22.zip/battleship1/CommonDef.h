//C++ BattleShip Project
//작성 일자 : 2018-06-02
//학번 : 20171656 이름 : 유성현
#ifndef __LOGGER__
#define __LOGGER__
#include <vector>
#include <iostream>

struct Position
{
	Position() : x(0), y(0) {}
	int x;
	int y;

	//������ �����ε�

	friend std::ostream& operator << (std::ostream& os, Position pos)//���ڿ� �������� ������ �� ���� operator.
	{
		os << "x : " << pos.x << " ";
		os << "y : " << pos.y;
		return os;
	}

	Position operator + (const Position& pos)
	{
		Position retPos;
		retPos.x = x + pos.x;
		retPos.y = y + pos.y;
		return retPos;
	}

	Position operator - (const Position& pos)
	{
		Position retPos;
		retPos.x = x - pos.x;
		retPos.y = y - pos.y;
		return retPos;
	}

	bool operator == (const Position& pos)
	{

		if ((pos.x == x) && (pos.y == y))
			return true;
		else
			return false;
	}
};

enum ShipType
{
	DATA_ERROR = -1,
	DATA_NONE,
	AIRCRAFT,
	BATTLESHIP,
	CRUISER,
	DESTROYER,
	sMISS,
	sHIT,

};

enum HitResult
{
	MISS,
	HIT,
	DESTROY,
	ALIVE,
};

static const int MAP_SIZE = 8;
static const int SHIP_COUNT = 5;
#define SHIPS std::vector<Ship*>

#endif
