#include "Cruiser.h"



Cruiser::Cruiser() : Ship(3)
{
	m_Type = CRUISER;
	
}


Cruiser::~Cruiser()
{
}
