#include "Destroyer.h"



Destroyer::Destroyer() : Ship(2)
{
	m_Type = DESTROYER;
}


Destroyer::~Destroyer()
{
}
