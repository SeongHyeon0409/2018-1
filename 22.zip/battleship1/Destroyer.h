//C++ BattleShip Project
//작성 일자 : 2018-06-02
//학번 : 20171656 이름 : 유성현


#include "Ship.h"
class Destroyer : public Ship
{
public:
	Destroyer();
	~Destroyer();
};
