
#include "GameManager.h"
#include "Player.h"
#include "Aircraft.h"
#include "Battleship.h"
#include "Cruiser.h"
#include "Destroyer.h"
#include <ncurses.h>
#include <iostream>

GameManager::GameManager()
{
	m_Attacker = NULL;
	m_Defender = NULL;
}

GameManager::~GameManager()
{
	if (m_Attacker)
	{
		delete m_Attacker;
		m_Attacker = NULL;
	}

	if (m_Defender)
	{
		delete m_Defender;
		m_Defender = NULL;
	}
}
void GameManager::Init()
{

	m_Turn = 0;
	shipCount = SHIP_COUNT;
	m_Attacker = new Player();
	m_Defender = new Player();

	std::vector<Ship*> vecShip;
	vecShip.push_back(new Aircraft());
	vecShip.push_back(new Battleship());
	vecShip.push_back(new Cruiser());
	vecShip.push_back(new Destroyer());
	vecShip.push_back(new Destroyer());

	//Aircraft* pAircraft = (Aircraft*)vecShip[0];
	//Battleship* pBS = (Battleship*)vecShip[1];

	initscr();
	start_color();
	init_pair(1, COLOR_WHITE, COLOR_RED);
	resize_term(35,60);
	border('*','*','*','*','*','*','*','*');
	mvprintw(1,1," Loading..");
	m_Defender->SetupShips(vecShip);
	clear();
	border('*','*','*','*','*','*','*','*');
	mvprintw(10, 20, "");
	mvprintw(15, 15, "");
	mvprintw(5, 20, "Input position (ex a3): ");
	mvprintw(1,2,"Defender");
	m_Defender->PrintMapA();

	mvprintw(12,2,"Attacker");
	m_Attacker->PrintMapB();

}

void GameManager::Play()
{

	while (shipCount) {

		m_Turn += 1;
		Position attackPos;
		mvprintw(5, 20, "Input position (ex a3): ");

		attackPos = m_Attacker->GetAttackPos();

		HitResult hitResult = m_Defender->HitCheck(attackPos);

		if (hitResult == HIT)
			{
				m_Defender->Attacked(attackPos);
				m_Attacker->HitMap(attackPos, hitResult);
				mvprintw(10, 20, "Hit!                         ");
			}
		if (hitResult == MISS)
			{
				m_Attacker->HitMap(attackPos, hitResult);
				mvprintw(10, 20, "Miss!                         ");
			}

		if (hitResult == DESTROY)
		{
				m_Defender->Attacked(attackPos);
				m_Attacker->HitMap(attackPos, hitResult);
				shipCount--;
				ShipType desCheck = m_Defender->Destroyed();
				if (desCheck != DATA_NONE)
				{
					switch (desCheck) {
					case AIRCRAFT:
						mvprintw(10, 20, "Aircraft was destroyed!  ");
						break;
					case BATTLESHIP:
						mvprintw(10, 20, "Battleship was destroyed!   ");
						break;
					case CRUISER:
						mvprintw(10, 20, "Cruiser was destroyed!   ");
						break;
					case DESTROYER:
						mvprintw(10, 20, "Destroyer was destroyed!  ");
						break;
					}//end switch
				}//end if
			}//end if
			border('*','*','*','*','*','*','*','*');
			mvprintw(1,20,"Turn : %d",m_Turn);
			mvprintw(1,2,"Defender");
			m_Defender->PrintMapA();

			mvprintw(12,2,"Attacker");
			m_Attacker->PrintMapB();


			refresh();
		}//end while


		mvprintw(20, 25, "GAME END");
		refresh();
		getch();
	  endwin();

}
	// while (shipCount) {
	// 	m_Turn += 1;
	// 	Position attackPos;
	// 	attackPos = m_Attacker->GetAttackPos();
	// 	HitResult hitResult = m_Defender->HitCheck(attackPos);
	//
	// 	if (hitResult == HIT)
	// 	{
	// 		m_Defender->Attacked(attackPos);
	// 		m_Attacker->HitMap(attackPos, hitResult);
	// 		std::cout << "HIT!" << std::endl;
	// 	}
	// 	if (hitResult == MISS) {
	// 		m_Attacker->HitMap(attackPos, hitResult);
	// 		std::cout << "MISS!" << std::endl;
	// 	}
	//
	// 	if (hitResult == DESTROY) {
	// 		m_Defender->Attacked(attackPos);
	// 		m_Attacker->HitMap(attackPos, hitResult);
	// 		shipCount--;
	// 		ShipType desCheck = m_Defender->Destroyed();
	// 		if (desCheck != DATA_NONE) {
	// 			switch (desCheck) {
	// 			case AIRCRAFT:
	// 				std::cout << "Aircraft was destroyed!" << std::endl;
	// 				break;
	// 			case BATTLESHIP:
	// 				std::cout << "Battleship was destroyed!" << std::endl;
	// 				break;
	// 			case CRUISER:
	// 				std::cout << "Cruiser was destroyed!" << std::endl;
	// 				break;
	// 			case DESTROYER:
	// 				std::cout << "Destroyer was destroyed!" << std::endl;
	// 				break;
	// 			}
	// 	}
	//
	//
	// 	}
	//
	// 	std::cout << "Turn : " << m_Turn << std::endl;
	// 	std::cout << "Defender" << std::endl;
	// 	std::cout << "Attacker" << std::endl;

	//}

	//std::cout << "==========GAME END===========" << std::endl;
