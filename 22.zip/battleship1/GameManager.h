//C++ BattleShip Project
//작성 일자 : 2018-06-02
//학번 : 20171656 이름 : 유성현


class Player;

class GameManager
{

public:
	GameManager();
	~GameManager();

	void Init();
	void Play();

protected:
	Player* m_Attacker;
	Player* m_Defender;
	int m_Turn;
	int shipCount;

};
