InputPane::InputPane(int x, int y, int width, int height)
  :Pane(x, y, width, height)
{
  mvwprintw(m_pWindow, 0, 3, "< INPUT >");
}

void StatPane::Draw()
{
  wattron(m_pWindow, COLOR_PAIR(3));
  mvwprintw(m_pWindow, 1, 2, "Input position ... (ex a 3)");
  mvwprintw(m_pWindow, 2, 2, "Input : ");
  mvwprintw(m_pWindow, COLOR_PARL(3));

  wrefresh(m_pWindow)
}
