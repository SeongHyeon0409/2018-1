//C++ BattleShip Project
//작성 일자 : 2018-06-02
//학번 : 20171656 이름 : 유성현


#include "CommonDef.h"

class Map
{
public:
	Map();
	~Map();

	ShipType GetData(const Position& pos);
	void SetData(const Position& pos, ShipType type);

protected:
	ShipType m_Data[MAP_SIZE][MAP_SIZE];
};
