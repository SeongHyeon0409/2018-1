#include "Player.h"
#include "Map.h"
#include "Ship.h"
#include <ctime>
#include <ncurses.h>
Player::Player()
{
	m_Map = new Map();
}

Player::~Player()
{
	delete m_Map;

	for (auto pShip : m_Ships)
	{
		if (pShip)
			delete pShip;
	}
	m_Ships.clear();
}

// void Player::printMap()
// {
// 	m_Map->PrintMapA();
// }

void Player::SetupShips(const SHIPS& ships)
{
	m_Ships = ships;

	for (auto pShip : m_Ships)
	{

		while (true)
		{
			Position pos;
			srand((int)time(NULL));
			pos.x = rand() % MAP_SIZE;
			pos.y = rand() % MAP_SIZE;
			ShipType dataType = m_Map->GetData(pos);
			if (dataType != DATA_NONE)
				continue;

			Position dir;
			if (rand() % 2) // x�����ΰ� y�����ΰ�
			{
				dir.x = rand() % 2 ? 1 : -1;
			}
			else
			{
				dir.y = rand() % 2 ? 1 : -1;
			}

			bool bSucess = true;
			for (int i = 0; i < pShip->GetLength(); i++)
			{
				pos = pos + dir;
				ShipType dataType = m_Map->GetData(pos);
				if (dataType != DATA_NONE)
				{
					bSucess = false;
					break;
				}

				pShip->SetPosition(i, pos);
			}

			if (bSucess)
			{
				//��ġ�Ϸ�
				std::vector<Position> shipVector = pShip->GetPosition();
				for (int i = 0; i < pShip->GetLength(); i++)
				{
					m_Map->SetData(shipVector[i], pShip->GetType());
				}
				break;
			}
		}//end while
		PrintMapA();
		refresh();
	}//end for

}

HitResult Player::HitCheck(const Position & pos)
{

	for (int i = 0; i < SHIP_COUNT; i++)
	{
		std::vector<Position> shipVector = m_Ships[i]->GetPosition();
		for (int j = 0; j < m_Ships[i]->GetLength(); j++)
		{
			if (shipVector[j] == pos && m_Ships[i]->GetHp() == 1)
				return DESTROY;
			else if (shipVector[j] == pos)
				return HIT;
		}
	}
	return MISS;
}

void Player::Attacked(const Position & pos)
{
	for (int i = 0; i < SHIP_COUNT; i++)
	{
		std::vector<Position> shipVector = m_Ships[i]->GetPosition();
		for (int j = 0; j < m_Ships[i]->GetLength(); j++)
			if (shipVector[j] == pos)
				m_Ships[i]->delPosition(pos);
	}
}

ShipType Player::Destroyed()
{
	for (int i = 0; i < SHIP_COUNT; i++)
		if (m_Ships[i]->GetHp() == 0) {
			m_Ships[i]->SetHp(-1);
			return m_Ships[i]->GetType();
		}

	return DATA_NONE;
}



Position Player::GetAttackPos()
{
	char clow[2];
	int low, col;
	Position pos;

	do{
		mvprintw(5, 20, "Input position (ex a3): ");
		scanw("%s", clow);
		low = clow[0];
		col = clow[1] - 49;
		if (low > 96 && low < 105)
			low -= 32;
		low -= 65;
	}while(low<0 || low>8 || col <0 || col>7);

	pos.x = low;
	pos.y = col;
	return pos;

}

void Player::HitMap(const Position & pos, const HitResult& hit)
{
	if (hit == HIT || hit == DESTROY)
		m_Map->SetData(pos, sHIT);
	else if (hit == MISS)
		m_Map->SetData(pos, sMISS);

}

void Player::PrintMapA()
{
	Position pos;
	char ch[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
	mvprintw(2, 1, "  12345678");
	for (int i = 0; i < MAP_SIZE; i++)
	{
		mvprintw(i+3, 2 ,&ch[i]);
		for (int j = 0; j < MAP_SIZE; j++)
		{
			pos.x = i;
			pos.y = j;
			if (m_Map->GetData(pos) == AIRCRAFT)
				mvprintw(i+3, j+3 ,"A");
			else if (m_Map->GetData(pos) == BATTLESHIP)
				mvprintw( i + 3, j+3 ,"B");
			else if (m_Map->GetData(pos) == CRUISER)
				mvprintw( i + 3, j+3 ,"C");
			else if (m_Map->GetData(pos) == DESTROYER)
				mvprintw( i + 3, j+3 ,"D");
			else if (m_Map->GetData(pos) == sMISS)
				mvprintw( i + 3, j+3 ,"X");
			else if (m_Map->GetData(pos) == sHIT)
				mvprintw( i + 3, j+3 ,"O");
			else
				mvprintw( i + 3, j+3 ,".");
		}
	}
}
void Player::PrintMapB()
{
	Position pos;
	char ch[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
	mvprintw(13, 1, "  12345678");
	for (int i = 0; i < MAP_SIZE; i++)
	{
		mvprintw(i+14, 2 ,&ch[i]);
		for (int j = 0; j < MAP_SIZE; j++)
		{
			pos.x = i;
			pos.y = j;
			if (m_Map->GetData(pos) == AIRCRAFT)
				mvprintw(i+14, j+3 ,"A");
			else if (m_Map->GetData(pos) == BATTLESHIP)
				mvprintw( i + 14, j+3 ,"B");
			else if (m_Map->GetData(pos) == CRUISER)
				mvprintw( i + 14, j+3 ,"C");
			else if (m_Map->GetData(pos) == DESTROYER)
				mvprintw( i + 14, j+3 ,"D");
			else if (m_Map->GetData(pos) == sMISS)
				mvprintw( i + 14, j+3 ,"X");
			else if (m_Map->GetData(pos) == sHIT)
				mvprintw( i + 14, j+3 ,"O");
			else
				mvprintw( i + 14, j+3 ,".");
		}
	}
}
