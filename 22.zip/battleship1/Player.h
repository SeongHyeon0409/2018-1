//C++ BattleShip Project
//작성 일자 : 2018-06-02
//학번 : 20171656 이름 : 유성현

#include "CommonDef.h"

class Map;
class Ship;

class Player
{
public:
	Player();
	~Player();

	void printMap();
	void PrintMapA();
	void PrintMapB();
	//Defender
	void SetupShips(const SHIPS& ships);
	HitResult HitCheck(const Position& pos);

	void Attacked(const Position & pos);
	ShipType Destroyed();

	//Attacker
	Position GetAttackPos();
	void HitMap(const Position& pos, const HitResult& hit);


protected:
	Map* m_Map;
	SHIPS m_Ships;

};
