#include "Ship.h"

Ship::Ship(int length) :m_length(length), m_hp(length)
{
	m_Pos.resize(length);
}

Ship::~Ship()
{
}

void Ship::SetPosition(int index, const Position & pos)
{
	m_Pos[index] = pos;
}

void Ship::delPosition(const Position& pos)
{
	for (int i = 0; i < m_length; i++)
	{
		if (m_Pos[i] == pos)
		{
			m_Pos[i].x = -1;
			m_Pos[i].y = -1;
			m_hp -= 1;
			break;
		}
	}

}
