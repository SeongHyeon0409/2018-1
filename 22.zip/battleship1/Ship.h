//C++ BattleShip Project
//작성 일자 : 2018-06-02
//학번 : 20171656 이름 : 유성현
#ifndef __LOGGERR__
#define __LOGGERR__
#include "CommonDef.h"

class Ship
{
public:
	Ship(int length);
	virtual ~Ship(); //���ӹ����Ÿ� ������ �Ҹ��ڿ� virtual

	ShipType GetType() const { return m_Type; }
	int GetLength() const { return m_length; }
	int GetHp() const { return m_hp; };
	void SetHp(const int hp) { m_hp = hp; }
	void SetPosition(int index, const Position & pos);
	void delPosition(const Position& pos);
	ShipType DieCheck();
	void Attacked();
	std::vector<Position> GetPosition() const { return m_Pos; };


protected:
	ShipType m_Type;
	int m_length;
	int m_hp;
	std::vector<Position> m_Pos;
	std::vector<Position> m_Pos2;
};

#endif
