#include <ncurses.h>

class test
{
public:

  void Draw()
  {
    char clow[8];
    int a, b;
    mvprintw(4,1,"A");
    scanw("%s", clow);

    mvprintw(5,5,clow);
    a = clow[0] - 96;
    b = clow[1]- 48;
    mvprintw(6,5,"%d",a);
    mvprintw(7,5,"%d",b);
  }
};

int main(void)
{
  test* ab;
  char clow[8];
  int a, b;
  initscr();
	start_color();
	init_pair(1, COLOR_WHITE, COLOR_RED);
	resize_term(35,80);

	border('*','*','*','*','*','*','*','*');
	mvprintw(1,1,"BattleShip");
  ab->Draw();
  scanw("%s", clow);

  mvprintw(5,5,clow);

  refresh();
  getch();
  endwin();

  return 0;
}
