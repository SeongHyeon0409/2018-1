#include "Aircraft.h"

Aircraft::Aircraft() : Ship(5)
{
    m_Type = AIRCRAFT;
}