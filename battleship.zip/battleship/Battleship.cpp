#include "Battleship.h"

Battleship::Battleship() : Ship(4)
{
    m_type = BATTLESHIP;
}