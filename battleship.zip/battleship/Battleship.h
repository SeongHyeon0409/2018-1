#include "Ship.h"

class Battleship : public Ship
{
public
    Battleship();
    ~Battleship();
};