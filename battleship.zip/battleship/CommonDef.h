#include <vector>
#include <iostream>

struct Position
{
    Position() : x(0), y(0) {}
    int x;
    int y;

    //연산자 오버로딩

    friend std::ostream& operator << (std::ostream& os, Position pos)//인자에 뭐가올지 정의할 수 없는 operator.
    {
        os << "x : " << pos.x << " ";
        os << "y : " << pos.y;
        return os;
    }
    
    Position operator + (const Position& pos) 
    {   
        Position retPos;
        retPos.x = x + pos.x;
        retPos.y = y + pos.y;
        return retPos;
    }

    Position operator - (const Position& pos)
    {   
        Position retPos;
        retPos.x = x - pos.x;
        retPos.y = y - pos.y;
        return retPos;
    }


};

enum ShipType
{
    DATA_ERROR = -1,
    DATA_NONE,
    AIRCRAFT,
    BATTLESHIP,
    CRUISER,
    DESTROYER,

};

enum HitResult
{
    MISS,
    HIT,
    DESTORY,
};

static const int MAP_SIZE = 8;

#define SHIPS std::vector<Ship*>