#include "Ship.h"

class Cruiser : public Ship
{
public
    BattleShip():
    ~BattleShip();
};