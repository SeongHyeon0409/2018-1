#include "Destroyer.h"

Destroyer::Destroyer() : Ship(2)
{
    m_type = DESTROYER;
}