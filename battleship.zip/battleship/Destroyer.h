#include "Ship.h"

class Destroyer : public Ship
{
public
    BattleShip():
    ~BattleShip();
};