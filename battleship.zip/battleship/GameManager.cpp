#include "GameManager.h"
#include "Player.h"
#include "Aircraft.h"
#include "Battleship.h"
#include "Cruiser.h"
#include "Destroyer.h"

GameManager::GameManager()
{
    m_Attacker = NULL;
    m_Defender = NULL;
}

GameManager::~GameManager()
{
    if(m_Attacker)
    {
        delete m_Attacker;
        m_Attacker = NULL;
    }

    if(m_Defender)
    {
        delete m_Defender;
        m_Defender = NULL;
    }
}

GameManager::Init()
{
    m_Attacker = new Player();
    m_Defender = new Defender();    

    std::vector<Ship*> vecShip;
    vecShip.push_back(new Aircraft());
    vecShip.push_back(new Battleship();
    vecShip.push_back(new Cruiser());
    vecShip.push_back(new Destroyer());
    vecShip.push_back(new Destroyer());

    Aircraft* pAircraft = (Aircraft*)vecShip[0];
    Battleship* pBS = (BattleShip*)vecShip[1];

    m_Dfender->SetupShips(vecShip);
}

GameManager::Play()
{

}