class  GameManager
{
public:
    GameManager();
    ~GameManager();

    void Init();
    void Play();

protected:
    Player m_Attacker;
    Player m_Defender;
};