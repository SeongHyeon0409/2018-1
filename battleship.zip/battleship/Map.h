#include "CommonDef.h"

//static const int MAP_SIZE = 8;

class Map
{
public:
    Map();
    ~Map();

    ShipType GetData(const Position& pos);
    {
        if(pos.x < 0 || pos.x>=MAP_SIZE || pos.y<0 || pos.y>=MAP_SIZE)
            return DATA_ERROR;
        return m_Data[pos.x][pos.y];
    }
    
    void SetData(const Position& pos, ShipType type)
    {
        if(pos.x < 0 || pos.x>=MAP_SIZE || pos.y<0 || pos.y>=MAP_SIZE)
            return;

        m_Data[pos.x][pos.y] = type;
    }
protected:
    ShipType m_Data[MAP_SIZE][MAP_SIZE];
};