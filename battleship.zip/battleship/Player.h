#include "CommonDef.h"
#define OUT //하는역할은 없이 명시용으로 쓰임

class Map;
class Ship;

class Player
{
public:
    Player();
    ~Player();

    //Defender
    void SetupShips(const SHIPS& ships);
    HitResult HitCheck(const Position& pos);

    //Attacker
    Position GetAttackPos();

protected:
    Map m_Map;
    SHIPS m_Ships;
};