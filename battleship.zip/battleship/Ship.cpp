#include "Ship.h"

Ship::Ship(int length)
    :m_length(length), m_hp(length)
{
    m_pos.resize(length);
    //m_pos.resize(length) > capasity도 만들고 실제 data도 채워놓음. size도 늘어남.
}

void Ship::SetPosition(int index, const Position & pos)
{
    m_Pos[index] = pos;
}