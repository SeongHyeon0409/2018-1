#include "CommonDef.h"

class Ship
{
public:
    Ship(int length);
    virtual ~Ship(); //상속받을거면 무조건 소멸자에 virtual

    ShipType GetType() const {return m_Type;}
    int GetLength() const {return m_length; }
    void AddPosition(const Position& pos);

protected:
    Shiptype m_Type;
    int m_length;
    int m_hp;
    std::vector<Position> m_Pos;
};