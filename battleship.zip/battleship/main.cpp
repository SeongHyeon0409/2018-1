#include "GameManager.h"
#include <iostream>

int main()
{
    Position pos;
    pos.x = 10;
    pos.y = 20;
    pos = pos + pos;
    std::cout << pos;

    
    // GameManager manager;
    // manager.Init();
    // manager.Play();

    return 0;
    
}