    
    // GameManager manager;
    // manager.Init();
    // manager.Play();
